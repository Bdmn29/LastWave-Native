package com.lastwave.app.data.local

/**
 * Selectable app typefaces (Settings -> Appearance -> App Font).
 *
 * [id] is what gets persisted. GOOGLE_SANS_FLEX is the bundled variable font,
 * the rest map to fonts every Android device ships, so no extra download.
 */
enum class AppFont(val id: String) {
    GOOGLE_SANS_FLEX("gsflex"),
    SYSTEM("system"),
    SANS("sans"),
    CONDENSED("condensed"),
    SERIF("serif"),
    MONOSPACE("mono"),
    CURSIVE("cursive");

    companion object {
        val DEFAULT: AppFont = GOOGLE_SANS_FLEX
        fun fromId(raw: String?): AppFont =
            entries.firstOrNull { it.id.equals(raw?.trim(), ignoreCase = true) } ?: DEFAULT
    }
}
