package com.lastwave.app.ui.player

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import kotlinx.coroutines.delay
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.util.lerp
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.lastwave.app.playback.MusicPlayerState
import kotlin.math.PI
import kotlin.math.sin

/**
 * Shifts the lightness and saturation of a Compose Color to produce
 * rich, dynamic tonal variations within the theme palette.
 */
private fun Color.shiftTonal(lightnessDelta: Float, saturationScale: Float = 1.0f): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.RGBToHSV(
        (red * 255).toInt().coerceIn(0, 255),
        (green * 255).toInt().coerceIn(0, 255),
        (blue * 255).toInt().coerceIn(0, 255),
        hsv,
    )
    val originalSaturation = hsv[1]
    hsv[1] = (hsv[1] * saturationScale).coerceIn(if (originalSaturation > 0.05f) 0.15f else 0.0f, 1.0f)
    hsv[2] = (hsv[2] + lightnessDelta).coerceIn(if (originalSaturation > 0.05f) 0.15f else 0.0f, 1.0f)
    val rgb = android.graphics.Color.HSVToColor(hsv)
    return Color(rgb)
}

/**
 * Ensures a color has sufficient brightness and saturation to stand out
 * vibrantly on dark scrims and backgrounds without washing out.
 */
private fun Color.ensureLuminousForDarkBackground(minBrightness: Float = 0.55f): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.RGBToHSV(
        (red * 255).toInt().coerceIn(0, 255),
        (green * 255).toInt().coerceIn(0, 255),
        (blue * 255).toInt().coerceIn(0, 255),
        hsv,
    )
    if (hsv[2] < minBrightness) {
        hsv[2] = minBrightness
    }
    if (hsv[1] in 0.05f..0.35f) {
        hsv[1] = 0.35f
    }
    return Color(android.graphics.Color.HSVToColor(hsv))
}

/**
 * Liquid Glass seekbar (Apple-style): a capsule track whose accent fill ends in
 * a translucent glass lens. The lens magnifies the track underneath it, carries
 * a rim light and a soft shadow, and swells while being dragged.
 *
 * Kept under the historical name `WavySeekBar` so every call site (player,
 * lyrics view) picks up the new look; touch handling is still the invisible
 * Material Slider layer below.
 */
@Composable
fun WavySeekBar(
    positionMs: Long,
    durationMs: Long,
    isPlaying: Boolean,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier,
    isTranslucent: Boolean = false,
    trackKey: String? = null,
    showTimeLabels: Boolean = true,
    primaryColor: Color = MaterialTheme.colorScheme.primary,
    secondaryColor: Color = MaterialTheme.colorScheme.secondary,
    tertiaryColor: Color = MaterialTheme.colorScheme.tertiary,
) {
    val interactionSource = remember(trackKey) { MutableInteractionSource() }
    var isInteracting by remember(trackKey) { mutableStateOf(false) }
    LaunchedEffect(interactionSource, trackKey) {
        var dragCount = 0
        var pressCount = 0
        interactionSource.interactions.collect { interaction ->
            when (interaction) {
                is DragInteraction.Start -> dragCount++
                is DragInteraction.Stop, is DragInteraction.Cancel -> dragCount = maxOf(0, dragCount - 1)
                is PressInteraction.Press -> pressCount++
                is PressInteraction.Release, is PressInteraction.Cancel -> pressCount = maxOf(0, pressCount - 1)
            }
            isInteracting = dragCount > 0 || pressCount > 0
        }
    }
    // Current-gesture drag value only; null = finger off, show live position.
    // Nullable (never a stale 0f) so a press that yields no onValueChange can
    // never seek anywhere, and a gesture that ends without
    // onValueChangeFinished can never pin the slider to a dead value.
    var dragPositionMs by remember(trackKey) { mutableStateOf<Float?>(null) }
    var lastSeekValue by remember(trackKey) { mutableStateOf<Float?>(null) }
    // Heal: framework reports finger lifted or cancelled but the finished callback
    // never ran -> drop the dead value and resume live position.
    LaunchedEffect(isInteracting, trackKey) {
        if (!isInteracting) {
            delay(120L)
            dragPositionMs = null
            lastSeekValue = null
        }
    }
    // Watchdog: if dragPositionMs was set by a tap/cancelled gesture while not interacting,
    // ensure it never permanently wedges the seekbar.
    LaunchedEffect(dragPositionMs, isInteracting, trackKey) {
        if (dragPositionMs != null && !isInteracting) {
            delay(250L)
            dragPositionMs = null
            lastSeekValue = null
        }
    }
    val dragging = isInteracting || dragPositionMs != null

    // ExoPlayer reports C.TIME_UNSET (-9223372036854775807) until the
    // container is parsed; coerce to 0 = unknown. Crucially, do NOT discard
    // position while duration is unknown: the old `else 0L` froze the time
    // label at 0:00 and pinned the bar, while the notification (system
    // extrapolation via speed) kept moving. Show real elapsed + "--:--"
    // until the duration arrives late, then fraction recovers automatically.
    val boundedDurationMs = durationMs.coerceAtLeast(0L)
    val boundedPositionMs = if (boundedDurationMs > 0L) {
        positionMs.coerceIn(0L, boundedDurationMs)
    } else {
        positionMs.coerceAtLeast(0L)
    }
    val shownMs = if (boundedDurationMs > 0L) {
        (dragPositionMs?.toLong() ?: boundedPositionMs).coerceIn(0L, boundedDurationMs)
    } else {
        (dragPositionMs?.toLong() ?: boundedPositionMs).coerceAtLeast(0L)
    }
    val shownFraction = if (boundedDurationMs > 0L) {
        (shownMs.toDouble() / boundedDurationMs.toDouble()).toFloat().coerceIn(0f, 1f)
    } else {
        0f
    }

    // Ensure colors stand out vibrantly on dark scrim/translucent backgrounds
    val effectivePrimary = remember(primaryColor, isTranslucent) {
        if (isTranslucent) primaryColor.ensureLuminousForDarkBackground(0.60f) else primaryColor
    }

    val inactiveColor = if (isTranslucent) {
        Color.White.copy(alpha = 0.24f)
    } else {
        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.16f)
    }
    val textColor = if (isTranslucent) {
        Color.White.copy(alpha = 0.85f)
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }

    // Fill gradient: deeper accent on the left -> lighter accent at the lens.
    val accentDark = remember(effectivePrimary) { effectivePrimary.shiftTonal(lightnessDelta = -0.14f, saturationScale = 1.25f) }
    val accentLight = remember(effectivePrimary) { effectivePrimary.shiftTonal(lightnessDelta = +0.14f, saturationScale = 0.95f) }

    // Liquid-glass lens "squish": it swells while the finger is down and
    // springs back (with a little overshoot) on release.
    val press by animateFloatAsState(
        targetValue = if (dragging) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
        label = "GlassLensPress",
    )

    val density = LocalDensity.current
    val trackThicknessPx = with(density) { 7.dp.toPx() }
    // Same 10dp horizontal inset the Material Slider touch layer uses, so the
    // drawn lens stays under the finger.
    val insetPx = with(density) { 10.dp.toPx() }
    val lensRestW = with(density) { 44.dp.toPx() }
    val lensRestH = with(density) { 29.dp.toPx() }
    val lensPressW = with(density) { 60.dp.toPx() }
    val lensPressH = with(density) { 40.dp.toPx() }
    val lensPath = remember { Path() }

    Column(modifier = modifier.fillMaxWidth()) {
        // Playback progress is time, not directional content: pin the whole
        // block (custom LTR Canvas drawing + invisible Material Slider touch
        // layer + time labels) to LTR. In RTL locales (Arabic, ...) the Slider
        // would otherwise mirror its gesture mapping while the drawing stays
        // LTR, inverting drag direction.
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
        ) {
            Canvas(modifier = Modifier.matchParentSize()) {
                val width = size.width
                val height = size.height
                val left = insetPx
                val right = (width - insetPx).coerceAtLeast(left + 1f)
                val trackW = right - left
                val cy = height / 2f
                val thumbX = left + shownFraction * trackW
                val tTop = cy - trackThicknessPx / 2f
                val tRadius = CornerRadius(trackThicknessPx / 2f)

                // 1. Inactive capsule track
                drawRoundRect(
                    color = inactiveColor,
                    topLeft = Offset(left, tTop),
                    size = Size(trackW, trackThicknessPx),
                    cornerRadius = tRadius,
                )

                // 2. Active fill (rounded end, like the Apple slider)
                if (thumbX > left) {
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            colors = listOf(accentDark, accentLight),
                            startX = left,
                            endX = thumbX.coerceAtLeast(left + 1f),
                        ),
                        topLeft = Offset(left, tTop),
                        size = Size(thumbX - left, trackThicknessPx),
                        cornerRadius = tRadius,
                    )
                }

                if (boundedDurationMs <= 0L) return@Canvas

                // 3. Liquid-glass lens
                val p = press.coerceIn(0f, 1.25f)
                val lensW = lerp(lensRestW, lensPressW, p)
                val lensH = lerp(lensRestH, lensPressH, p)
                val lensLeft = thumbX - lensW / 2f
                val lensTop = cy - lensH / 2f
                val lensTopLeft = Offset(lensLeft, lensTop)
                val lensSize = Size(lensW, lensH)
                val lensRadius = CornerRadius(lensH * 0.5f)

                lensPath.reset()
                lensPath.addRoundRect(
                    RoundRect(
                        left = lensLeft,
                        top = lensTop,
                        right = lensLeft + lensW,
                        bottom = lensTop + lensH,
                        radiusX = lensH * 0.5f,
                        radiusY = lensH * 0.5f,
                    ),
                )

                // 3a. Soft drop shadow, kept OUTSIDE the lens so the glass body
                // stays clear.
                val shadowAlpha = if (isTranslucent) 0.10f else 0.07f
                clipPath(lensPath, clipOp = ClipOp.Difference) {
                    for (step in 1..5) {
                        val grow = step * 1.6.dp.toPx()
                        drawRoundRect(
                            color = Color.Black.copy(alpha = shadowAlpha),
                            topLeft = Offset(lensLeft - grow, lensTop - grow + 2.5.dp.toPx()),
                            size = Size(lensW + 2f * grow, lensH + 2f * grow),
                            cornerRadius = CornerRadius(lensH * 0.5f + grow),
                        )
                    }
                }

                // 3b. Glass body: faint frosted wash + the track magnified
                // (refracted) as seen through the lens.
                clipPath(lensPath) {
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.White.copy(alpha = if (isTranslucent) 0.16f else 0.34f),
                                Color.White.copy(alpha = if (isTranslucent) 0.05f else 0.12f),
                            ),
                            startY = lensTop,
                            endY = lensTop + lensH,
                        ),
                        topLeft = lensTopLeft,
                        size = lensSize,
                    )

                    val magnified = 1.30f + 0.30f * p.coerceAtMost(1f)
                    val mH = trackThicknessPx * magnified
                    val mTop = cy - mH / 2f
                    val mRadius = CornerRadius(mH / 2f)
                    drawRoundRect(
                        color = inactiveColor.copy(alpha = (inactiveColor.alpha * 1.6f).coerceAtMost(0.5f)),
                        topLeft = Offset(left, mTop),
                        size = Size(trackW, mH),
                        cornerRadius = mRadius,
                    )
                    if (thumbX > left) {
                        drawRoundRect(
                            brush = Brush.horizontalGradient(
                                colors = listOf(accentDark, accentLight),
                                startX = left,
                                endX = thumbX.coerceAtLeast(left + 1f),
                            ),
                            topLeft = Offset(left, mTop),
                            size = Size(thumbX - left, mH),
                            cornerRadius = mRadius,
                        )
                    }

                    // Top specular sheen
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color.White.copy(alpha = 0.40f), Color.Transparent),
                            startY = lensTop,
                            endY = lensTop + lensH * 0.45f,
                        ),
                        topLeft = Offset(lensLeft + lensH * 0.18f, lensTop + 1.5.dp.toPx()),
                        size = Size((lensW - lensH * 0.36f).coerceAtLeast(1f), lensH * 0.42f),
                        cornerRadius = CornerRadius(lensH * 0.21f),
                    )
                }

                // 3c. Rim light: bright top-left and bottom edge, clear in between.
                drawRoundRect(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.95f),
                            Color.White.copy(alpha = 0.10f),
                            Color.White.copy(alpha = 0.10f),
                            Color.White.copy(alpha = 0.75f),
                        ),
                        start = lensTopLeft,
                        end = Offset(lensLeft + lensW, lensTop + lensH),
                    ),
                    topLeft = lensTopLeft,
                    size = lensSize,
                    cornerRadius = lensRadius,
                    style = Stroke(width = 1.3.dp.toPx()),
                )
                // Left-edge refraction tinted by the accent colour
                drawRoundRect(
                    brush = Brush.horizontalGradient(
                        colors = listOf(accentLight.copy(alpha = 0.60f), Color.Transparent),
                        startX = lensLeft,
                        endX = lensLeft + lensW * 0.28f,
                    ),
                    topLeft = lensTopLeft,
                    size = lensSize,
                    cornerRadius = lensRadius,
                    style = Stroke(width = 1.6.dp.toPx()),
                )
                // Hairline outside the rim so the glass reads on any background
                val hair = 0.6.dp.toPx()
                drawRoundRect(
                    color = Color.Black.copy(alpha = if (isTranslucent) 0.28f else 0.10f),
                    topLeft = Offset(lensLeft - hair, lensTop - hair),
                    size = Size(lensW + 2f * hair, lensH + 2f * hair),
                    cornerRadius = CornerRadius(lensH * 0.5f + hair),
                    style = Stroke(width = 0.8.dp.toPx()),
                )
            }

            Slider(
                // When duration is unknown the bar is indeterminate (fraction 0):
                // pin the invisible touch layer to 0 so a real elapsed time
                // (e.g. 5000ms with range 0..1) can't coerce to the end stop.
                // Once the late duration arrives, value/range recover together.
                value = if (boundedDurationMs > 0L) shownMs.toFloat().coerceIn(0f, boundedDurationMs.toFloat()) else 0f,
                onValueChange = {
                    dragPositionMs = it
                    lastSeekValue = it
                },
                onValueChangeFinished = {
                    // Commit only this gesture's value; a finished callback
                    // with no value (press without movement) seeks nowhere.
                    // Guarded by enabled above, but re-check: no duration = no seek.
                    if (boundedDurationMs <= 0L) {
                        dragPositionMs = null
                        lastSeekValue = null
                        return@Slider
                    }
                    val target = (lastSeekValue ?: dragPositionMs)?.toLong()?.coerceIn(0L, boundedDurationMs)
                    dragPositionMs = null
                    lastSeekValue = null
                    if (target != null) onSeek(target)
                },
                valueRange = 0f..boundedDurationMs.coerceAtLeast(1L).toFloat(),
                enabled = boundedDurationMs > 0L,
                interactionSource = interactionSource,
                modifier = Modifier.matchParentSize(),
                colors = SliderDefaults.colors(
                    thumbColor = Color.Transparent,
                    activeTrackColor = Color.Transparent,
                    inactiveTrackColor = Color.Transparent,
                    activeTickColor = Color.Transparent,
                    inactiveTickColor = Color.Transparent,
                    disabledThumbColor = Color.Transparent,
                    disabledActiveTrackColor = Color.Transparent,
                    disabledInactiveTrackColor = Color.Transparent,
                ),
            )
        }

        if (showTimeLabels) {
            Spacer(Modifier.height(2.dp))

            // Time labels
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = formatTime(shownMs),
                    style = if (isTranslucent) MaterialTheme.typography.labelSmall.copy(fontWeight = androidx.compose.ui.text.font.FontWeight.Medium) else MaterialTheme.typography.labelMedium,
                    color = textColor,
                )
                Text(
                    text = if (boundedDurationMs > 0L) "−${formatTime((boundedDurationMs - shownMs).coerceAtLeast(0))}" else "--:--",
                    style = if (isTranslucent) MaterialTheme.typography.labelSmall.copy(fontWeight = androidx.compose.ui.text.font.FontWeight.Medium) else MaterialTheme.typography.labelMedium,
                    color = textColor,
                )
            }
        }
        }
    }
}

@Composable
fun WavySeekBar(
    state: MusicPlayerState,
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier,
    isTranslucent: Boolean = false,
    primaryColor: Color = MaterialTheme.colorScheme.primary,
    secondaryColor: Color = MaterialTheme.colorScheme.secondary,
    tertiaryColor: Color = MaterialTheme.colorScheme.tertiary,
) {
    WavySeekBar(
        positionMs = state.positionMs,
        durationMs = state.durationMs,
        isPlaying = state.isPlaying,
        onSeek = onSeek,
        modifier = modifier,
        isTranslucent = isTranslucent,
        trackKey = state.current?.let { it.videoId ?: "${it.artist}|${it.title}" },
        primaryColor = primaryColor,
        secondaryColor = secondaryColor,
        tertiaryColor = tertiaryColor,
    )
}

